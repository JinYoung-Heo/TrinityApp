package com.example.naengbiseo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.fragment_base_main.*
import kotlinx.android.synthetic.main.fragment_base_start.*
import kotlinx.android.synthetic.main.fragment_cold_start.*
import kotlinx.android.synthetic.main.fragment_cold_start.view.*
import kotlinx.android.synthetic.main.host_activity.*

class BaseStartFragment:Fragment() {
    private val tabTextList = arrayListOf("선반", "냉장실", "냉동실")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_base_start, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val main_activity = activity as MainActivity // 프래그먼트에서 액티비티 접근하는 법 꼭 기억하자!!!!
        view_pager_start.adapter = ViewPagerAdapter(childFragmentManager,lifecycle)
        TabLayoutMediator(main_activity.tabLayout, view_pager_start) { //탭레이아웃과 뷰페이저 연결
                tab, position ->
            tab.text = tabTextList[position]
        }.attach()
        view_pager_start.offscreenPageLimit = 2 //프래그먼트 깨지는거 방지
        view_pager_start.currentItem = 1 // 뷰페이저 처음 위치 지정.
    }
}