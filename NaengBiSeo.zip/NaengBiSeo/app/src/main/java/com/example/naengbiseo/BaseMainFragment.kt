package com.example.naengbiseo

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.fragment_base_main.*
import kotlinx.android.synthetic.main.host_activity.*

class BaseMainFragment :Fragment(){
    private val args: BaseMainFragmentArgs by navArgs()
    private val tabTextList = arrayListOf("선반", "냉장실", "냉동실")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        return inflater.inflate(R.layout.fragment_base_main, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mainActivity = activity as MainActivity // 프래그먼트에서 액티비티 접근하는 법 꼭 기억하자!!!!
        view_pager_main.adapter = ViewPagerAdapter2(childFragmentManager,lifecycle)
        view_pager_main.offscreenPageLimit = 2 //프래그먼트 깨지는거 방지
        TabLayoutMediator(mainActivity.tabLayout, view_pager_main) { //탭레이아웃과 뷰페이저 연결
                tab, position ->
            view_pager_main.currentItem = 2
            //view_pager_main.currentItem = args.a1.toString().toInt()
            tab.text = tabTextList[position]
        }.attach()


    }


}